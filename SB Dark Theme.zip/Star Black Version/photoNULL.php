<?php
if (!defined("IN_SB")) {
    echo "You should not be here. Only follow links!";
    die();
}
setcookie("profilePhoto", "none", time()-9999999);

?>